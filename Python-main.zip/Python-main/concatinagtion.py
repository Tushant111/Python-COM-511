first = "vivek"
last = "koul"

result = "My first name is: "+first+"\nMy last name is :"+last
print(result)
name = "hi there"
print(len(name))


print(name[0])
print(name[0:4])

print(name.upper())

# text = " hi there have fun with nmo stresssssss "

# text_upper = text.upper()
# text_stripped = text.strip()
# text_lstripped = text.lstrip()
# text_rstripped = text.rstrip()
# replace_text = text.replace("there","where")
# word_list = text.split(",")
# start_with_hello = text.startswith(" ")
# ends_with_exclama = text.endswith(" ")
# text="python is awesome"
# sentence = text.split(" ")
# joined_text = "-".join(text)

# print(text_upper)
# print(text_stripped)
# print(text_lstripped)
# print(text_rstripped)
# print(replace_text)
# print(word_list)
# print(start_with_hello)
# print(ends_with_exclama)
# print(sentence)00
# print(joined_text)
def function1(a,b=90):
    print("value of a",a)
    print("value of b")
function1("chand")