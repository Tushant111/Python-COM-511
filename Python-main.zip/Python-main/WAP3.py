# #Consider the string welcome to python world.......
# a=input("Enter the number")
# c=0
# for i in a:
#     c+=1 #c will increment as the value of a is increased
# print(c)
#Consider the string welcome to python world.......
#For alphanumeric
# a=input("Enter the number")
# c=0
# for i in a:
#     if(i.isalpha()):
#      c+=1 #c will increment as the value of a is increased
# print(c)

# #slicing 
# a=input("Enter input")
# print(a[10:17])


#Alpha Numeric
a=input("Enter the number")
c=0
for i in a:
    if(i.isalnum()):
     c+=1 #c will increment as the value of a is increased
print(c)