#Loops
#When a task is repeated again and again.It is used to perform repetetive task.
#For,while,do while,neted loop,loop control statement
#For (for loop):
#it is used to iterate over a sequence such as list,tuple,string or any range and execute the block of code in sequence
#for(initialization,condition,inc/dec)
