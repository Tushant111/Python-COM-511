#SLICING
my_list=['V','I','V','E','k']
print(my_list[1:3])
print(my_list[2:])
print(my_list[:])

