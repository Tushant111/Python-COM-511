# list1=[10,10.5,'Apple',34,47]
# length=len(list1)
# for i in list1:
#     print(i)
# for i in range(length):
#     print(i,list1(i))

#To reduce the compplexity
# list1=[10,10.5,'Apple',34,47]
# [print(i)for i in list1]
my_list = [10,10.5,'Apple',34,47]

for index, item in enumerate(my_list):
    print(f"Index: {index}, Item: {item}")
#we have to do in lab manual

#dictionary
dict={"1":"name","age":20,"city":"Jammu"}
print(dict.keys()x)