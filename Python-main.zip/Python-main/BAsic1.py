#addition without + operator
# a=10
# b=20
# for i in range(b):
#     a=a + 1
# print (a)

#addition without * operator
# a=10
# b=20
# c=0
# for i in range(1,b):
#     a=a+2
# print(a)
