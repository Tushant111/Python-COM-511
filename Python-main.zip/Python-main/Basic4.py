#addition subtraction multiplication and division
a=10
b=20
print("Addition:",a+b)
print("Mult:",a*b)
print("Sub:",a-b)
print("div:",a/b)