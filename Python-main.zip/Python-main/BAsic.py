#programming language is used to for communcation between human and machines.
#PYthon language was developed by Guido Van Rossum 02/1991
#First laguage was "C" and was developed in 70s.
#It is an actively developed language.
# It is not a case sensitive language.
#There are 26 impplementations in Python,but the msot common are:Cpython,Jython,Iron Python.
#Python has headers but are hidden
#There are two types of data types primitive and non primitive
# primitive can store numbers non premitive can store characters
#Boolean:yes/No True/False (then use if and else loop).
#Source code is the code that we write.
# Source code is converted into bytecode by the compiler as CPU doesnot understand the source code that we write.
#Built in functions:Predefined in the language example:-print,input,mini,max,sum,type,len etc.
# these are predefined functions we just have to call.
#ceil value is above .5 and value below .5 is floor value...... ciel<=5
#types of conversion:-
#1)Explicit:we are going to use an external input funnction for conversion. int(),float(),str()etc.
#2)Implicit:Compiler is going to do itself.
#3)Binary,Octal,Hexadecimal Conversion
#4)
#5)custom conversion

#Loops
#When a task is repeated again and again.It is used to perform repetetive task.
#For,while,do while,neted loop,loop control statement
#For (for loop):
#it is used to iterate over a sequence such as list,tuple,string or any range and execute the block of code in sequence
#for(initialization,condition,inc/dec)

